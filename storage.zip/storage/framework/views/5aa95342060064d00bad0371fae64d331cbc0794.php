<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('category')->html();
} elseif ($_instance->childHasBeenRendered('o3HF9YI')) {
    $componentId = $_instance->getRenderedChildComponentId('o3HF9YI');
    $componentTag = $_instance->getRenderedChildComponentTagName('o3HF9YI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('o3HF9YI');
} else {
    $response = \Livewire\Livewire::mount('category');
    $html = $response->html();
    $_instance->logRenderedChild('o3HF9YI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
        </div>
    </div>
</div>

 <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelLiveWireCrude\resources\views/home.blade.php ENDPATH**/ ?>