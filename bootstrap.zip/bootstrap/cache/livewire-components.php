<?php return array (
  'category' => 'App\\Http\\Livewire\\Category',
);